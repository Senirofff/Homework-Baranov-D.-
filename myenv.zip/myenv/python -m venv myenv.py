import random

print("Крестики-нолики")

while True:
    # выбираем размер поля
    n = 0
    while n < 3 and n > 9:
        try:
            n = int(input("\nРазмер поля (от 3 и до 9): "))
        except:
            n = 0

    # создаём поле из точек
    p = [["."] * n for _ in range(n)]

    # кто ходит первым — случайно
    x = random.choice(["X", "O"])
    print("Первым ходит:", x)

    while True:
        # рисуем поле
        print()
        for r in p:
            print(" ".join(r))

        # ход игрока
        while True:
            try:
                a, b = map(int, input(f"Ход {x} → строка столбец: ").split())
                a -= 1
                b -= 1
                if 0 <= a < n and 0 <= b < n and p[a][b] == ".":
                    break
                print("Нельзя сюда!")
            except:
                print("Пиши два числа через пробел!")

        p[a][b] = x

        # проверка победы по строкам и столбцам
        win = False
        for i in range(n):
            if all(p[i][j] == x for j in range(n)) or all(p[j][i] == x for j in range(n)):
                win = True
        # диагонали
        if n >= 3:
            if p[0][0] == x and p[1][1] == x and p[2][2] == x:
                win = True
            if p[0][2] == x and p[1][1] == x and p[2][0] == x:
                win = True

        if win:
            print("\nПобедил", x, "!!!")
            for r in p:
                print(" ".join(r))
            break

        # ничья
        if all(all(c != "." for c in r) for r in p):
            print("\nНичья!")
            for r in p:
                print(" ".join(r))
            break

        # смена игрока
        x = "O" if x == "X" else "X"

    # играть ещё?
    if input("\nЕщё партию? (да/нет): ").lower() not in ["да","yes","y","д","+"]:
        print("Пока! Приходи ещё")
        break
    print("-" * 30)
